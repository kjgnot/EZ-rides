# EZ Rides Android prototype

This project packages the EZ Rides web prototype inside an Android WebView. It is a prototype, not a production-ready ride-hailing service.

## Build an APK using GitHub Actions (no Android Studio required)

1. Download and extract this ZIP.
2. Create a new GitHub repository (for example, `ez-rides-android`).
3. Upload the *contents* of the `EZRidesAndroid` folder to the repository root. The `.github/workflows/build-apk.yml` file must be included.
4. Open the repository's **Actions** tab. If GitHub asks, enable Actions for the repository.
5. Select **Build EZ Rides APK** and press **Run workflow**. If it is not listed yet, make a commit/push to the `main` branch first.
6. Wait for the workflow to finish with a green check mark.
7. Open that completed workflow run and download the **EZ-Rides-debug-APK** artifact.
8. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Transfer that APK to your Android phone and install it. You may need to allow installation from that source.

The cloud build requires a GitHub account and internet access. This project ZIP is not itself an APK, and an APK is not included until the workflow successfully builds it.

## Prototype limitations

- Passenger and driver data is stored locally on the device; different phones do not yet share accounts or ride requests.
- The admin/driver credentials and verification flow in the prototype are for demonstration only. Do not use real passwords or sensitive information.
- Supabase authentication, database rules, server-side verification-code issuance, live ride dispatch, notifications, production mapping/routing, and a signed release APK still need implementation before public launch.
